import React from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet-async';
import { Code, Palette, MessageSquare, Briefcase } from 'lucide-react';
import HeroSection from '../components/HeroSection';
import Skills from '../components/Skills';

const features = [
  {
    icon: <Code size={24} />,
    title: 'Web Development',
    description: 'Creating responsive and modern web applications using cutting-edge technologies.'
  },
  {
    icon: <Palette size={24} />,
    title: 'Graphics Design',
    description: 'Designing beautiful and intuitive user interfaces for exceptional user experiences.'
  },
  {
    icon: <MessageSquare size={24} />,
    title: 'AI Prompting',
    description: 'Implementing AI-powered features and optimizing prompts for better results.'
  },
  {
    icon: <Briefcase size={24} />,
    title: 'Digital Marketing',
    description: 'Developing comprehensive digital marketing strategies for business growth.'
  }
];

const Home = () => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="min-h-screen"
    >
      <Helmet>
        <title>Elisha Ejimofor - Web Developer & Digital Marketer</title>
        <meta
          name="description"
          content="Portfolio of Elisha Ejimofor, a skilled web developer, designer, and digital marketer specializing in AI optimization."
        />
      </Helmet>

      <section className="bg-gradient-to-b from-indigo-50 to-white dark:from-gray-900 dark:to-gray-800">
        <div className="container mx-auto px-4 py-16">
          <HeroSection />
        </div>
      </section>

      <section className="py-16 bg-white dark:bg-gray-800">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-white dark:bg-gray-700 p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow"
              >
                <div className="text-indigo-600 mb-4">{feature.icon}</div>
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-gray-600 dark:text-gray-300">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 bg-gray-50 dark:bg-gray-900">
        <div className="container mx-auto px-4">
          <Skills />
        </div>
      </section>
    </motion.div>
  );
};

export default Home;