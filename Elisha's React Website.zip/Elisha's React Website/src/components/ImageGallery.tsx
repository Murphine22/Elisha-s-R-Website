import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

const images = [
  // Coding/Development
  'https://images.unsplash.com/photo-1555066931-4365d14bab8c?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80',
  
  // Web Design
  'https://images.unsplash.com/photo-1547658719-da2b51169166?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80',
  
  // Content Creation
  'https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80',
  
  // AI/Innovation
  'https://images.unsplash.com/photo-1677442136019-21780ecad995?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80',
  
  // Graphic Design
  'https://images.unsplash.com/photo-1626785774573-4b799315345d?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80',
  
  // Modern Robotics
  'https://images.unsplash.com/photo-1535378917042-10a22c95931a?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80',
  
  // Tech Innovation
  'https://images.unsplash.com/photo-1451187580459-43490279c0fa?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80',
  
  // Future Technology
  'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80'
];

const ImageGallery = () => {
    const [currentIndex, setCurrentIndex] = useState(0);

    useEffect(() => {
        const interval = setInterval(() => {
            setCurrentIndex((prevIndex) => (prevIndex + 1) % images.length);
        }, 5000); // Increased duration to 5 seconds per image

        return () => clearInterval(interval);
    }, []);

    return (
        <div className="relative w-full h-full">
            <motion.img
                key={currentIndex}
                src={images[currentIndex]}
                alt="Slideshow"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 1 }} // Smoother transition
                className="w-full h-full object-cover rounded-2xl"
            />
        </div>
    );
};

export default ImageGallery;