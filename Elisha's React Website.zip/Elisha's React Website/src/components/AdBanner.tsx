import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const ads = [
  {
    id: 1,
    title: "Master Modern Web Development",
    description: "Learn React, Node.js, and Modern JavaScript",
    link: "#",
    bgColor: "bg-gradient-to-r from-blue-600 to-indigo-600",
    image: "https://images.unsplash.com/photo-1627398242454-45a1465c2479?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80"
  },
  {
    id: 2,
    title: "AI Development Tools",
    description: "Build intelligent applications with our AI toolkit",
    link: "#",
    bgColor: "bg-gradient-to-r from-purple-600 to-pink-600",
    image: "https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80"
  },
  {
    id: 3,
    title: "Cloud Computing Solutions",
    description: "Scale your applications with modern cloud technology",
    link: "#",
    bgColor: "bg-gradient-to-r from-green-600 to-teal-600",
    image: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80"
  }
];

const AdBanner = () => {
  const [currentAd, setCurrentAd] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentAd((prev) => (prev + 1) % ads.length);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="w-full sticky top-0 z-40">
      <AnimatePresence mode="wait">
        <motion.div
          key={currentAd}
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 20 }}
          className={`w-full ${ads[currentAd].bgColor} text-white`}
        >
          <div className="container mx-auto">
            <div className="flex items-center justify-between p-4">
              <div className="flex items-center space-x-6">
                <img 
                  src={ads[currentAd].image} 
                  alt={ads[currentAd].title}
                  className="w-32 h-20 rounded-lg object-cover"
                />
                <div>
                  <h3 className="text-xl font-bold mb-1">{ads[currentAd].title}</h3>
                  <p className="text-sm md:text-base">{ads[currentAd].description}</p>
                </div>
              </div>
              <button className="px-6 py-2 bg-white text-gray-900 rounded-full text-sm font-semibold hover:bg-gray-100 transition-colors">
                Learn More
              </button>
            </div>
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
};

export default AdBanner;