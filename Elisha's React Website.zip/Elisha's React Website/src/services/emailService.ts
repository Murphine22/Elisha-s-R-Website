import emailjs from '@emailjs/browser';

// Initialize EmailJS with your public key
emailjs.init("gku95plt4vAMfWQ7t"); // Your EmailJS public key

const EMAILJS_SERVICE_ID = 'Murphine240891';      // Your EmailJS service ID
const EMAILJS_TEMPLATE_ID = '_ejs-test-mail-service_';    // Your EmailJS template ID

export const sendEmail = async (formData: {
  name: string;
  email: string;
  subject: string;
  message: string;
}) => {
  try {
    const templateParams = {
      to_name: "Elisha Ejimofor",
      from_name: formData.name,
      from_email: formData.email,
      subject: formData.subject,
      message: formData.message,
      reply_to: formData.email
    };

    const response = await emailjs.send(
      EMAILJS_SERVICE_ID,
      EMAILJS_TEMPLATE_ID,
      templateParams
    );
    
    return response;
  } catch (error) {
    console.error('Email send error:', error);
    throw error;
  }
};